import React from 'react';
export const Banner00DataSource = {
  wrapper: { className: 'banner0 lcgh7a6bt1q-editor_css' },
  textWrapper: { className: 'banner0-text-wrapper' },
  title: {
    className: 'banner0-title lck5a3aqrg-editor_css',
    children: (
      <span>
        <h2>
          <span>
            <span>
              <span>
                <span>
                  <blockquote>
                    <span>
                      <span>
                        <span>
                          <span>
                            <span>
                              <span>
                                <span>
                                  <span>
                                    <span>
                                      <span>
                                        <span />
                                      </span>
                                    </span>
                                  </span>
                                </span>
                              </span>
                            </span>
                          </span>
                        </span>
                      </span>
                    </span>
                  </blockquote>
                </span>
              </span>
            </span>
          </span>
        </h2>
        <h2>
          <span>
            <span>
              <span>
                <span>
                  <blockquote>
                    <span>
                      <span>
                        <span>
                          <span>
                            <span>
                              <span>
                                <span>
                                  <span>
                                    <span>
                                      <span>
                                        <span />
                                      </span>
                                    </span>
                                  </span>
                                </span>
                              </span>
                            </span>
                          </span>
                        </span>
                      </span>
                    </span>
                  </blockquote>
                </span>
              </span>
            </span>
          </span>
        </h2>
        <h2>
          <span>
            <span>
              <span>
                <span>
                  <blockquote>
                    <span>
                      <span>
                        <span>
                          <span>
                            <span>
                              <span>
                                <span>
                                  <span>
                                    <span>
                                      <span>
                                        <span>
                                          <blockquote>
                                            <h3>
                                              <b>Spirit Detective</b>
                                            </h3>
                                          </blockquote>
                                        </span>
                                      </span>
                                    </span>
                                  </span>
                                </span>
                              </span>
                            </span>
                          </span>
                        </span>
                      </span>
                    </span>
                  </blockquote>
                </span>
              </span>
            </span>
          </span>
        </h2>
        <h2>
          <span>
            <span>
              <span>
                <span>
                  <blockquote>
                    <span>
                      <span>
                        <span>
                          <span>
                            <span>
                              <span>
                                <span>
                                  <span>
                                    <span>
                                      <span>
                                        <span />
                                      </span>
                                    </span>
                                  </span>
                                </span>
                              </span>
                            </span>
                          </span>
                        </span>
                      </span>
                    </span>
                  </blockquote>
                </span>
              </span>
            </span>
          </span>
        </h2>
      </span>
    ),
  },
  content: {
    className: 'banner0-content lck5iadehvl-editor_css',
    children: (
      <span>
        <span>
          <span>
            <span>
              <span>
                <span>
                  <span>
                    <span>
                      <span>
                        <span>
                          <span>
                            <span>
                              <span>
                                <span>
                                  <span>
                                    <p>
                                      <b>
                                        We Show The Truth of Unexpected Deaths
                                      </b>
                                    </p>
                                    <p>
                                      If you die in the memory, forget the{' '}
                                      <b>SPACE</b>, <br />
                                    </p>
                                    <p>
                                      you must <b>ESC</b>ape<br />
                                    </p>
                                  </span>
                                </span>
                              </span>
                            </span>
                          </span>
                        </span>
                      </span>
                    </span>
                  </span>
                </span>
              </span>
            </span>
          </span>
        </span>
      </span>
    ),
  },
  button: {
    className: 'banner0-button lck5itzt4k-editor_css',
    children: (
      <span>
        <span>
          <span>
            <span>
              <p>
                Enter Memory<br />
              </p>
            </span>
          </span>
        </span>
      </span>
    ),
    href:
      'https://drive.google.com/file/d/14jWC27UYw1am8nIl2rTnPSdLRo6eqBTQ/view?usp=share_link',
    type: 'default',
    target: '',
  },
};
